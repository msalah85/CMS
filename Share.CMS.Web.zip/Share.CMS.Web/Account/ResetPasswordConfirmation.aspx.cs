﻿using System.Web.UI;

namespace Share.CMS.Web.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}